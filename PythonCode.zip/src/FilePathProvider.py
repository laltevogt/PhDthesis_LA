

def get_input_path():
    #return "C:/Users/Jannik/PycharmProjects/gcodehandlerrepo/resources/210812_LOCK_vase.gcode"
    return "C:/Users/lucaa/Desktop/pycharm projects/gcodehandlerrepo/resources/230712/gridtest_out.gcode"

def get_output_path():
    #return "C:/Users/Jannik/PycharmProjects/gcodehandlerrepo/resources/210812_LOCK_vase_out.gcode"
    return "C:/Users/lucaa/Desktop/pycharm projects/gcodehandlerrepo/resources/230712/output/gridtest_8.gcode"