import re
import numpy as np


class GCodeProcessor:

    @staticmethod
    def apply_constant_pressure(gcode, pressure):
        gcode.e_vals[0] = 0.7
        current_x = 0
        current_y = 0
        current_z = 0
        current_e = 0.7
        current_f = float('NaN')

        for idx in range(1, len(gcode.x_vals)):
            if not np.isnan(gcode.x_vals[idx-1]):
                current_x = gcode.x_vals[idx-1]
            if not np.isnan(gcode.y_vals[idx-1]):
                current_y = gcode.y_vals[idx-1]
            if not np.isnan(gcode.z_vals[idx-1]):
                current_z = gcode.z_vals[idx-1]

            if not np.isnan(gcode.e_vals[idx]):
                x_distance = 0 if np.isnan(gcode.x_vals[idx]) else gcode.x_vals[idx]-current_x
                y_distance = 0 if np.isnan(gcode.y_vals[idx]) else gcode.y_vals[idx]-current_y
                z_distance = 0 if np.isnan(gcode.z_vals[idx]) else gcode.z_vals[idx]-current_z

                dist = (x_distance**2 + y_distance**2 + z_distance**2)**0.5
                current_e += dist*pressure
                gcode.e_vals[idx] = current_e

        lines = gcode.gcode_str.split('\n')
        line_number = 0
        updated_gcode_str = ""
        for line in lines:
            if line.startswith("G1"):
                updated_gcode_str += re.sub("E([\d|.]+)", "E"+"{:.3f}".format(gcode.e_vals[line_number]), line)+"\n"
                line_number += 1
            else:
                updated_gcode_str += line + "\n"
        gcode.gcode_str = updated_gcode_str
        return gcode

    @staticmethod
    def cut_filament(gcode, pressure):
        for e_validx in reversed(range(1,len(gcode.e_vals))):
            if not np.isnan(gcode.e_vals[e_validx]):
                gcode.e_vals[e_validx]+=pressure
                break

        gcode.e_vals[len(gcode.e_vals)-1]+=1.5
        lines = gcode.gcode_str.split('\n')
        line_number = 0
        updated_gcode_str = ""
        for line in lines:
            if line.startswith("G1") and gcode.e_vals[line_number] != float('NaN'):
                updated_gcode_str += re.sub("E([\d|.]+)", "E"+"{:.3f}".format(gcode.e_vals[line_number]), line)+"\n"
                line_number += 1
            else:
                updated_gcode_str += line + "\n"
        gcode.gcode_str = updated_gcode_str
        return gcode
