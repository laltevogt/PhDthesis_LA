from GCodeProcessor import GCodeProcessor
from GCodeReader import GCodeReader
from GCodeWriter import GCodeWriter
import FilePathProvider

if __name__ == "__main__":
    input_path = FilePathProvider.get_input_path()
    output_path = FilePathProvider.get_output_path()
    reader = GCodeReader()
    gcode = reader.read(input_path)
    processor = GCodeProcessor()
    processor.apply_constant_pressure(gcode,0.14)
    processor.cut_filament(gcode,pressure=1.5)
    writer = GCodeWriter()
    writer.write(gcode,output_path)