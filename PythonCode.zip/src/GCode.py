
# This internal gcode representation would be better if the field gcode_str wasn't needed,
# but doing more would be overkill. There is a github project with a complete internal representation:
# https://github.com/jminardi/mecode/blob/e8efbf6b8e03964d682e74b9e7d2a6d0b72ccb74/mecode/main.py#L89
# (This may fit your need, but I'm not sure it has a reader)
class GCode:

    def __init__(self, x_vals, y_vals, z_vals, e_vals, f_vals, gcode_str):
        self.x_vals = x_vals
        self.y_vals = y_vals
        self.z_vals = z_vals
        self.e_vals = e_vals
        self.f_vals = f_vals
        self.gcode_str = gcode_str

    def __str__(self):
        return self.gcode_str