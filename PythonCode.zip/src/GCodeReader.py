from GCode import GCode

import re


class GCodeReader:

    #def read(self, path):
    #    x = []
    #   y = []
    #  e = []
    # with open(path, 'r') as f_gcode:
    #    gcode_str = f_gcode.read()
    #re_value = re.search('filament used = .*? \(([0-9.]+)', gcode_str)
    #lines = gcode_str.split('\n')
    #for line in lines:
    #   if line.startswith("G1 ") and "X" in line and "Y" in line and "E" in line:
    #       x.append(float(re.search("X(.*) Y", line).group(1)))
    #       y.append(float(re.search("Y(.*) E", line).group(1)))
    #       e.append(float(re.search("E(.*)", line).group(1)))
    #return GCode(x, y, e, gcode_str)

    def read(self, path):
        x = []
        y = []
        z = []
        e = []
        f = []
        with open(path, 'r') as f_gcode:
            gcode_str = f_gcode.read()
        #re_value = re.search('filament used = .*? \(([0-9.]+)', gcode_str)
        lines = gcode_str.split('\n')
        for line in lines:
            if line.startswith("G1"):
                if 'X' in line:
                    x.append(float(re.search("X([\d|.-]+)", line).group(1)))
                else:
                    x.append(float('NaN'))
                if 'Y' in line:
                    y.append(float(re.search("Y([\d|.-]+)", line).group(1)))
                else:
                    y.append(float('NaN'))
                if 'Z' in line:
                    z.append(float(re.search("Z([\d|.]+)", line).group(1)))
                else:
                    z.append(float('NaN'))
                if 'E' in line:
                    e.append(float(re.search("E([\d|.]+)", line).group(1)))
                else:
                    e.append(float('NaN'))
                if 'F' in line:
                    f.append(float(re.search("F([\d|.]+)", line).group(1)))
                else:
                    f.append(float('NaN'))
        return GCode(x, y, z, e, f, gcode_str)
