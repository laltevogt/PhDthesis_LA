

class GCodeWriter:

    def write(self, gcode, path):
        with open(path, 'w') as f:
            f.writelines(gcode.gcode_str)
            f.close()